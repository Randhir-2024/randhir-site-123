
import React from 'react';
import { UserCheck, Zap, Globe, Lock } from 'lucide-react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-24 bg-zinc-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="relative">
            <div className="aspect-square rounded-3xl overflow-hidden glass-card border-zinc-800">
              <img
                src="https://picsum.photos/seed/it-infrastructure/800/800"
                alt="IT Infrastructure"
                className="object-cover w-full h-full opacity-60 grayscale hover:grayscale-0 transition-all duration-700"
              />
            </div>
            {/* Stats overlay */}
            <div className="absolute -bottom-6 -right-6 glass-card p-6 rounded-2xl border-blue-500/30">
              <div className="text-3xl font-bold text-blue-500 mb-1">5+</div>
              <div className="text-sm font-medium text-zinc-400">Years Expert<br />Experience</div>
            </div>
          </div>

          <div>
            <h2 className="text-3xl font-bold text-white mb-6">Expertise in Private Cloud & Data Sovereignty</h2>
            <p className="text-lg text-zinc-400 mb-8 leading-relaxed">
              I am a dedicated Private Cloud & Infrastructure Consultant focused on helping organizations reclaim control over their digital assets. By moving away from vendor lock-in, I design systems that provide enterprise-grade reliability with the flexibility of open-source innovation.
            </p>
            
            <div className="space-y-6">
              {[
                {
                  icon: <Globe className="h-5 w-5 text-blue-400" />,
                  title: "Independence",
                  desc: "Building infrastructures that don't rely on restrictive proprietary clouds."
                },
                {
                  icon: <Zap className="h-5 w-5 text-indigo-400" />,
                  title: "Performance",
                  desc: "Optimized virtualization stacks using Proxmox and distributed storage."
                },
                {
                  icon: <Lock className="h-5 w-5 text-emerald-400" />,
                  title: "Privacy First",
                  desc: "Self-hosted alternatives like Nextcloud and private AI (Ollama) to keep your data yours."
                },
                {
                  icon: <UserCheck className="h-5 w-5 text-amber-400" />,
                  title: "Consultative Approach",
                  desc: "I work as a partner to understand your business goals first, technology second."
                }
              ].map((item, idx) => (
                <div key={idx} className="flex items-start gap-4">
                  <div className="mt-1 bg-zinc-900 p-2 rounded-lg">{item.icon}</div>
                  <div>
                    <h4 className="font-semibold text-white">{item.title}</h4>
                    <p className="text-sm text-zinc-500">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
