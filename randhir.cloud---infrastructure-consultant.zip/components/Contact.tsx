
import React, { useState } from 'react';
import { Mail, MessageSquare, Send, CheckCircle2 } from 'lucide-react';

const Contact: React.FC = () => {
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate form submission
    setIsSubmitted(true);
    setTimeout(() => setIsSubmitted(false), 5000);
  };

  return (
    <section id="contact" className="py-24 bg-zinc-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="glass-card rounded-[3rem] overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            
            {/* Contact Info */}
            <div className="p-8 md:p-16 bg-blue-600 relative overflow-hidden">
              <div className="relative z-10">
                <h2 className="text-4xl font-bold text-white mb-6">Let's build your <br />cloud today.</h2>
                <p className="text-blue-100 text-lg mb-12 opacity-90">
                  Ready to move your infrastructure to the next level? Reach out for a free consultation and project audit.
                </p>

                <div className="space-y-8">
                  <div className="flex items-center gap-6 group">
                    <div className="bg-white/10 p-4 rounded-2xl group-hover:bg-white/20 transition-colors">
                      <Mail className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <p className="text-blue-200 text-sm font-medium uppercase tracking-widest">Email me</p>
                      <a href="mailto:randhir.iimt.2024@gmail.com" className="text-xl font-bold text-white hover:underline underline-offset-4">
                        randhir.iimt.2024@gmail.com
                      </a>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-6 group">
                    <div className="bg-white/10 p-4 rounded-2xl group-hover:bg-white/20 transition-colors">
                      <MessageSquare className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <p className="text-blue-200 text-sm font-medium uppercase tracking-widest">Location</p>
                      <p className="text-xl font-bold text-white">Remote / Worldwide</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Decorative circle */}
              <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
              <div className="absolute -top-12 -right-12 w-48 h-48 bg-blue-400/20 rounded-full blur-2xl"></div>
            </div>

            {/* Form */}
            <div className="p-8 md:p-16 bg-zinc-900">
              {isSubmitted ? (
                <div className="h-full flex flex-col items-center justify-center text-center space-y-4 py-20 animate-in zoom-in-95">
                  <div className="bg-emerald-500/20 p-6 rounded-full text-emerald-500">
                    <CheckCircle2 className="h-16 w-16" />
                  </div>
                  <h3 className="text-2xl font-bold text-white">Message Sent Successfully!</h3>
                  <p className="text-zinc-400">I will get back to you within 24 hours.</p>
                  <button 
                    onClick={() => setIsSubmitted(false)}
                    className="mt-6 text-blue-400 hover:text-blue-300 font-semibold"
                  >
                    Send another message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-zinc-400 mb-2">Full Name</label>
                      <input
                        required
                        type="text"
                        className="w-full bg-zinc-800/50 border border-zinc-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 transition-all"
                        placeholder="John Doe"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-zinc-400 mb-2">Email Address</label>
                      <input
                        required
                        type="email"
                        className="w-full bg-zinc-800/50 border border-zinc-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 transition-all"
                        placeholder="john@example.com"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-zinc-400 mb-2">Subject</label>
                    <input
                      required
                      type="text"
                      className="w-full bg-zinc-800/50 border border-zinc-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 transition-all"
                      placeholder="Infrastructure Setup Inquiry"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-zinc-400 mb-2">Message</label>
                    <textarea
                      required
                      rows={5}
                      className="w-full bg-zinc-800/50 border border-zinc-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 transition-all"
                      placeholder="Tell me about your project needs..."
                    ></textarea>
                  </div>
                  <button
                    type="submit"
                    className="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition-all shadow-xl shadow-blue-500/20 flex items-center justify-center gap-2"
                  >
                    Send Message <Send className="h-5 w-5" />
                  </button>
                </form>
              )}
            </div>

          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
