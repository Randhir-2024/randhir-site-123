
import React from 'react';

const TechStack: React.FC = () => {
  const techs = [
    { name: "Proxmox", category: "Virtualization" },
    { name: "Ceph", category: "Storage" },
    { name: "WHMCS", category: "Billing" },
    { name: "Nextcloud", category: "SaaS" },
    { name: "PetaSAN", category: "Storage" },
    { name: "Plesk", category: "Control Panel" },
    { name: "cPanel", category: "Control Panel" },
    { name: "Acronis", category: "Backup" },
    { name: "Ollama", category: "AI" },
    { name: "n8n", category: "Automation" },
    { name: "Linux", category: "Core OS" },
    { name: "Networking", category: "Connectivity" }
  ];

  return (
    <section id="tech" className="py-24 bg-zinc-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-end justify-between mb-16 gap-4">
          <div className="max-w-xl">
            <h2 className="text-blue-500 font-bold tracking-widest uppercase text-sm mb-4">Stack & Tools</h2>
            <h3 className="text-4xl font-bold text-white">Advanced Platform Expertise</h3>
          </div>
          <p className="text-zinc-500 text-sm">
            Mastering the tools that power the next generation of private clouds.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {techs.map((tech, idx) => (
            <div
              key={idx}
              className="glass-card group flex flex-col items-center justify-center p-8 rounded-2xl hover:bg-zinc-900 transition-all border border-zinc-800"
            >
              {/* Placeholder SVG Icon based on tech name */}
              <div className="w-12 h-12 mb-4 bg-zinc-800 rounded-lg flex items-center justify-center text-zinc-400 font-bold text-lg group-hover:bg-blue-600 group-hover:text-white transition-colors">
                {tech.name.substring(0, 1)}
              </div>
              <span className="text-sm font-semibold text-zinc-100 mb-1">{tech.name}</span>
              <span className="text-[10px] uppercase tracking-wider text-zinc-600 font-bold">{tech.category}</span>
            </div>
          ))}
        </div>
        
        <div className="mt-12 text-center text-zinc-600 text-xs italic">
          * All trademarks belong to their respective owners. Logos represented here are stylistic placeholders.
        </div>
      </div>
    </section>
  );
};

export default TechStack;
