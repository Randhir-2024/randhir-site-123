
import React from 'react';
import { ArrowRight, ShieldCheck, Cpu, HardDrive } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section id="hero" className="relative pt-32 pb-20 md:pt-48 md:pb-32 overflow-hidden hero-gradient">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center">
          <div className="inline-flex items-center space-x-2 bg-blue-500/10 border border-blue-500/20 rounded-full px-4 py-1 mb-8">
            <span className="flex h-2 w-2 rounded-full bg-blue-500 animate-pulse"></span>
            <span className="text-xs font-semibold text-blue-400 uppercase tracking-wider">Available for new projects</span>
          </div>
          <h1 className="text-5xl md:text-7xl font-extrabold text-white mb-6 tracking-tight leading-tight">
            Private Cloud & <br />
            <span className="bg-gradient-to-r from-blue-400 via-indigo-400 to-blue-600 bg-clip-text text-transparent">
              Infrastructure Consultant
            </span>
          </h1>
          <p className="max-w-2xl mx-auto text-lg md:text-xl text-zinc-400 mb-10 leading-relaxed">
            Architecting secure, scalable, and self-hosted cloud solutions. From virtualization and high-availability storage to automated AI deployments.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a
              href="#contact"
              className="w-full sm:w-auto px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition-all shadow-xl shadow-blue-500/30 flex items-center justify-center gap-2"
            >
              Contact Me <ArrowRight className="h-5 w-5" />
            </a>
            <a
              href="#services"
              className="w-full sm:w-auto px-8 py-4 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 font-bold rounded-xl border border-zinc-700 transition-all flex items-center justify-center gap-2"
            >
              Our Expertise
            </a>
          </div>
        </div>

        {/* Feature badges */}
        <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="glass-card p-6 rounded-2xl flex items-start gap-4">
            <div className="bg-blue-500/20 p-3 rounded-lg text-blue-400">
              <ShieldCheck className="h-6 w-6" />
            </div>
            <div>
              <h3 className="font-semibold text-white mb-1">Secure by Design</h3>
              <p className="text-sm text-zinc-400">Integrated VAPT and rigorous security protocols for every deployment.</p>
            </div>
          </div>
          <div className="glass-card p-6 rounded-2xl flex items-start gap-4">
            <div className="bg-indigo-500/20 p-3 rounded-lg text-indigo-400">
              <HardDrive className="h-6 w-6" />
            </div>
            <div>
              <h3 className="font-semibold text-white mb-1">Enterprise Storage</h3>
              <p className="text-sm text-zinc-400">High availability solutions using Ceph, PetaSAN, and Proxmox.</p>
            </div>
          </div>
          <div className="glass-card p-6 rounded-2xl flex items-start gap-4">
            <div className="bg-emerald-500/20 p-3 rounded-lg text-emerald-400">
              <Cpu className="h-6 w-6" />
            </div>
            <div>
              <h3 className="font-semibold text-white mb-1">Self-Hosted AI</h3>
              <p className="text-sm text-zinc-400">Harnessing Ollama and automation via n8n on your local infrastructure.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Background decoration */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-full h-px bg-gradient-to-r from-transparent via-zinc-800 to-transparent"></div>
    </section>
  );
};

export default Hero;
