
import React from 'react';
import { Cloud, Linkedin, Github, Twitter } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="py-12 bg-zinc-950 border-t border-zinc-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center space-x-2">
            <Cloud className="h-6 w-6 text-blue-500" />
            <span className="text-lg font-bold text-white tracking-tight">randhir.cloud</span>
            <span className="hidden md:inline text-zinc-600 px-2">|</span>
            <span className="text-zinc-500 text-sm">Private Cloud & Infrastructure Specialist</span>
          </div>

          <div className="flex space-x-6">
            <a href="#" className="text-zinc-500 hover:text-white transition-colors">
              <Linkedin className="h-5 w-5" />
            </a>
            <a href="#" className="text-zinc-500 hover:text-white transition-colors">
              <Github className="h-5 w-5" />
            </a>
            <a href="#" className="text-zinc-500 hover:text-white transition-colors">
              <Twitter className="h-5 w-5" />
            </a>
          </div>
        </div>
        
        <div className="mt-8 pt-8 border-t border-zinc-900/50 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-zinc-600">
          <p>© {new Date().getFullYear()} randhir.cloud – All rights reserved.</p>
          <div className="flex space-x-4">
            <a href="#" className="hover:text-zinc-400">Privacy Policy</a>
            <a href="#" className="hover:text-zinc-400">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
