
import React from 'react';
import { Server, Database, Activity, Bot, ShieldAlert, CloudLightning } from 'lucide-react';

const Services: React.FC = () => {
  const services = [
    {
      icon: <ShieldAlert className="h-10 w-10 text-red-400" />,
      title: "VAPT",
      description: "Comprehensive Vulnerability Assessment and Penetration Testing to secure your network perimeter and internal workloads."
    },
    {
      icon: <Server className="h-10 w-10 text-blue-400" />,
      title: "Private Cloud Setup",
      description: "End-to-end architecting using Proxmox VE, WHMCS integration, and customized VM templates for rapid deployment.",
      features: ["Proxmox VE & Backup Server", "Plesk / cPanel hosting stacks", "WHMCS Automation"]
    },
    {
      icon: <CloudLightning className="h-10 w-10 text-indigo-400" />,
      title: "Self-Hosted Collaboration",
      description: "Nextcloud deployment for file sharing, communication, and productivity without third-party data collection.",
      features: ["File Sync & Share", "Collabora/OnlyOffice Integration"]
    },
    {
      icon: <Database className="h-10 w-10 text-emerald-400" />,
      title: "Storage & Backup",
      description: "High-performance storage clusters using Ceph, PetaSAN, and Acronis Cyber Protect for ironclad business continuity.",
      features: ["Ceph Distributed Storage", "PetaSAN iSCSI clusters", "Off-site Backups"]
    },
    {
      icon: <Bot className="h-10 w-10 text-purple-400" />,
      title: "AI & Automation",
      description: "Future-proof your workflows with local LLMs via Ollama and visual automation with n8n.",
      features: ["Ollama Local AI", "n8n Workflow Automation", "Custom API Integrations"]
    },
    {
      icon: <Activity className="h-10 w-10 text-amber-400" />,
      title: "Infrastructure Monitoring",
      description: "Real-time health monitoring and alerting systems to ensure 99.9% uptime for your critical services."
    }
  ];

  return (
    <section id="services" className="py-24 bg-zinc-900/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-blue-500 font-bold tracking-widest uppercase text-sm mb-4">What I Do</h2>
          <h3 className="text-4xl md:text-5xl font-bold text-white mb-6">Full-Stack Infrastructure Services</h3>
          <p className="max-w-2xl mx-auto text-zinc-400 text-lg">
            Providing expert consulting on modern self-hosted stacks that empower businesses with reliability and control.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, idx) => (
            <div key={idx} className="group glass-card p-8 rounded-3xl hover:border-zinc-600 transition-all duration-300">
              <div className="mb-6 transform group-hover:scale-110 transition-transform duration-300">{service.icon}</div>
              <h4 className="text-xl font-bold text-white mb-4">{service.title}</h4>
              <p className="text-zinc-400 text-sm mb-6 leading-relaxed">{service.description}</p>
              {service.features && (
                <ul className="space-y-2">
                  {service.features.map((f, i) => (
                    <li key={i} className="flex items-center gap-2 text-xs text-zinc-500">
                      <div className="h-1 w-1 rounded-full bg-blue-500"></div>
                      {f}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
